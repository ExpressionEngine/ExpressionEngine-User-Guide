<?php

error_reporting(E_ALL);
define('EXT', '.php');

if ( ! isset($_GET['convert']))
{
	echo "<h2>Forum Theme Conversion Utility</h2>
	
<p>This utility helps automate the conversion of a forum theme from version Discussion Forum version 2.x to Discussion Forum version 3.x.  To use this
utility, place it within the directory of the forum theme you wish to convert, modify the permissions of that folder to be writeable.</p>

<p>When you have done the above and are ready to proceed, click <a href='?convert=yes'>here</a></p>";
	exit;
}

$pathinfo = pathinfo(__FILE__);
$files = array();
$path = rtrim(realpath('.'), DIRECTORY_SEPARATOR);

if ( ! is_writable($path))
{
	exit('directory not writable');
}


if ($fp = opendir($path))
{
	$path = $path.DIRECTORY_SEPARATOR;

	while (FALSE !== ($file = readdir($fp)))
	{
		if ( ! is_dir($path.$file) && substr($file, -4) == '.php' && $file != $pathinfo['filename'].'.'.$pathinfo['extension'])
		{
			$files[] = $file;
		}
	}
}
else
{
	exit('error reading directory');
}

closedir($fp);

$new_theme_dir = $path.'converted_theme';

mkdir($new_theme_dir);
chmod($new_theme_dir, 0777);

foreach ($files as $file)
{
	// include the file
	require_once($path.$file);
	
	// instantiate the class
	$class = str_replace('.php', '', $file);
	$obj = new $class;

	// create new directory
	$new_dir = $new_theme_dir.'/'.str_replace('theme_', 'forum_', $class);
	mkdir($new_dir);
	chmod($new_dir, 0777);

	// create the new files
	foreach (get_class_methods($obj) AS $method)
	{
		$new_file = $method.'.html';
		
		if ( ! $fp = fopen($new_dir.'/'.$new_file, 'w'))
		{
			exit("<strong>Fatal error: Could not write file {$new_dir}/{$new_file}</strong>");
		}

		flock($fp, LOCK_EX);
		fwrite($fp, $obj->$method());
		flock($fp, LOCK_UN);
		fclose($fp);
	}
}

echo "<h2>Template Conversion Completed</h2>

<p>You can replace the files in your theme folder with the folders located inside <strong>{$new_theme_dir}</strong>
(make sure to retain the 'images' folder and any other non-PHP files that your theme contained), and delete this file.  Please adjust permissions on this folder and the included folders
and files to the least permission necessary on your server necessary.</p>

<p>At a minimum, they need to be readable (typically 755 for directories and 644 for files), though if you want
to be able to edit your theme from within your control panel, they will need writable permissions.  Please
contact your server administrator for the correct permissions to use for your needs.</p>";

// end of convert_forum_theme.php script