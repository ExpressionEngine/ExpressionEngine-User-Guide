<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Publish_page_api {

	var $files		= array();

	/**
	 * Constructor
	 *
	 * @access	public
	 */
	function Publish_page_api()
	{
		$this->EE =& get_instance();

	}
	
	function update_publish()
	{
		
	}
	
	function publish_fields()
	{
		
	}


	// --------------------------------------------------------------------
	
}

/* End of file publish_page_api.php */
/* Location: ./system/expressionengine/third_party/modules/download/publish_page_api.php */