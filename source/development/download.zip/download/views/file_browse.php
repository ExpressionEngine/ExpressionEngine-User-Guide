		<div id="file_manager">

			<div id="file_manager_holder">
				<!--<div class="main_tab solo" id="file_manager_list"> -->

				<?php if (count($file_list) == 0):?>

						<p class="notice"><?=lang('no_upload_dirs')?></p>

				<?php else:?>

					<?=form_open($action_url, array('id'=>'files_form'))?>

					<?php 
						$this->table->set_template($cp_table_template);

						foreach ($file_list as $directory_info):
					?>

							<h3><?=$directory_info['name']?></h3>

							<div id="dir_id_<?=$directory_info['id']?>" style="display:<?=$directory_info['display']?>; margin-bottom:10px">
							<?php
								// without the div above, the slide effect breaks the table widths

								$this->table->set_heading(
											lang('file_name'),
											lang('file_size'),
											lang('kind'),
											lang('date'),
											form_checkbox('select_all', 'true', FALSE, 'class="toggle_all"')
														);

								// no results?  Give the "no files" message
								if (count($directory_info['files']) == 0)
								{
									$this->table->add_row(array('data' => lang('no_uploaded_files'), 'colspan' => 5, 'class' => 'no_files_warning'));
								}
								else
								{
									// Create a row for each file
									foreach ($directory_info['files'] as $file)
									{
										$this->table->add_row($file);
									}
								}
								echo $this->table->generate();
								$this->table->clear(); // needed to reset the table
							?>
							</div>

					<?php endforeach;?>
					<input type="submit" class="submit" value="<?=lang('create_download_files')?>" />
					<?=form_close()?>

				<?php endif;?>

</div>
</div>