		<div class="pageContents">

			<?=form_open('C=addons_modules'.AMP.'M=show_module_cp'.AMP.'module=download'.AMP.'method=update_downloads')?>

							<?php
							
								// without the div above, the slide effect breaks the table widths

								$this->table->set_template($cp_table_template);
								$this->table->set_heading(
														lang('file_name'),
														lang('file_title'),
														lang('access')
														);

								// no results?  Give the "no files" message
								
								if (count($file_info) == 0)
								{
									$this->table->add_row(array('data' => lang('no_uploaded_files'), 'colspan' => 3, 'class' => 'no_files_warning'));
								}
								else
								{
									// Create a row for each file
									foreach ($file_info as $file)
									{	
								
									$this->table->add_row(
									$file['file_name'].
									form_hidden('file_dir['.$file['id'].']', $file['file_dir']).
									form_hidden('file_name['.$file['id'].']', $file['file_name']).
									form_hidden('file_id['.$file['id'].']', $file['file_id']),
									form_input('file_title['.$file['id'].']', set_value('file_title', $file['file_title']), 'id="file_title"'),
									form_multiselect('member_access['.$file['id'].'][]', $member_groups_dropdown, set_value('member_access['.$file['file_id'].']', $file['member_access']))									
																		
									);
									}
								}
								echo $this->table->generate();
								$this->table->clear(); // needed to reset the table
							?>
							</div>

					<input type="submit" class="submit" value="<?=lang('create_download_files')?>" />
					<?=form_close()?>


		</div>
	</div><!-- contents -->
