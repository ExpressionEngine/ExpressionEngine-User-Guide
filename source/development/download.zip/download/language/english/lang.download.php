<?php
$lang = array(

"download_module_name" 			=> 'Download Module',
"download_module_description" 	=> 'Allows forced and protected file downloads', 
'no_matching_files' 			=> 'No matching files', 
'add_download' 					=> 'Add Download',
'download_config' 				=> 'Module Configuration',
'edit_items' 					=> 'Downloadable Items',
'download_files'				=> 'Download Files',

'file_name' =>
'File name',

'download' =>
'Download',

'bad' =>
'bad data',

'id_field_instructions' =>
'Allows downloadable files to be associated with this entry',

'file_title' => 
'File title',

'access' => 
'Member access',

'edit_selected' => 
'Edit selected',

'delete_selected' => 
'Delete selected',

'file_size' => 
'File size',

'kind' => 
'Kind',

'create_download_files' => 
'Create download files',

'submit' => 
'Submit', 

'add_files' =>
'Add Files',

'edit_files' =>
'Edit Files',

'edit_file' =>
'Edit File',

'delete_file' => 
'Delete file',

'delete_files' => 
'Delete Files',

'file_deleted' => 
'File deleted',

'files_deleted' => 
'Files deleted',

'download_delete_question' => 
'Are you certain you want to delete these download records',

'invalid_download' =>
'Invalid download',

'no_permission' =>
'You do not have permission to access this file',


//
''=>''
);